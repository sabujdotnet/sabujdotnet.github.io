Mikrotik Template Login for [PHPNuxBill](https://github.com/hotspotbilling/phpnuxbill)
----

**.:English:.**

This Template is for Mikrotik Login Hotspot, just put all File inside hotspot folder in Mikrotik, overwrite all. You need to have [PHPNuxBill](https://github.com/hotspotbilling/phpnuxbill) installed somewhere.

You need to edit this file, find **TODO**, and follow instruction:

 - login.html
 - status.html
 - logout.html
 - remove **errors.txt** rename **errors.en.txt** to **errors.txt**

 replace **background.jpg** file with your own background

 Delete folder remove!


**.:Indonesia:.**

Template ini untuk Login Hotspot Mikrotik, upload dan timpa semua file ke folder hotspot, pastikan anda juga telah memasang [PHPNuxBill](https://github.com/hotspotbilling/phpnuxbill) di suatu server.

Sebelum digunakan edit dulu file dibawah, Cari **TODO** dan ikuti petunjuknya:

 - login.html
 - status.html
 - logout.html
 - hapus **errors.txt**, ganti nama **errors.en.txt** ke **errors.txt**

 Ganti **background.jpg** dengan Background anda sendiri

 hapus folder remove!

DONT FORGET!! JANGAN LUPA!!!
----
Add your PHPNuxBill server IP or domain to walled garden hotspot

Tambahkan alamat IP atau domain PHPNuxBill server ke walled garden hotspot



Explanation | Penjelasan
----

![Static Pages](remove_me/info.png)

CREDITS
----
Masjid Agung Banten Wallpaper taken from [www.bantenwisata.com](http://www.bantenwisata.com/2015/09/masjid-agung-banten.html)

Template created using [Bootstrap v3.3.7](http://getbootstrap.com)